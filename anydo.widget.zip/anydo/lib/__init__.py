""" anydo.lib """
