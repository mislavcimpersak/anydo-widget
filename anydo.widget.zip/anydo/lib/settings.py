# -*- coding: utf-8 -*-
""" anydo.lib.settings """
PROXIES = None
USERNAME = "username@example.org"
PASSWORD = "password"
